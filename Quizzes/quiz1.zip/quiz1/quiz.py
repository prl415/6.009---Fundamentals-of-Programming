# NO IMPORTS!

##################################################
### Problem 1: batch
##################################################

def batch(inp, size):
    """ Return a list of batches, per quiz specification """
    batches = []
    batch = []
    for e in inp:
        batch.append(e)
        if sum(batch) >= size:
            batches.append(batch)
            batch = []
            
    #Deal with the last batch
    if len(batch) != 0:
        batches.append(batch)
        
    return batches
    
##################################################
### Problem 2: order
##################################################

def order(inp):
    """ Return an ordered list of string, per quiz specification """
    ordered = []
    #Create a dictionary where key is a letter and value is the index where
    #the letter is seen first
    mapping = {}
    for i, s in enumerate(inp):
        mapping.setdefault(s[0], []).append(i)
    
    #Now we have to create a list which represents the order of indices 
    l = sorted([val for val in mapping.values()])
    order_list = []
    for e in l:
        order_list.extend(e)
                
    for index in order_list:
        ordered.append(inp[index])
        
    return ordered
            
##################################################
### Problem 3: path_to_happiness
##################################################

def path_to_happiness(field):
    """ Return a path through field of smiles that maximizes happiness """
    nrows = field['nrows']
    ncols = field['ncols']
    smile_land = field['smiles']
    
    def update_map(smile_map, col):
        '''
        Adds a new col to the smile_map. In new col, each cell represents the 
        sum of the path from first column to column col. Returns updated 
        smile_map
        '''
        if nrows == 1:
            smile_map[0].append(smile_land[0][col] + smile_map[0][col-1])
            return smile_map
        
        for r in range(nrows):
            if r == 0:
                smile_map[r].append(smile_land[r][col] + max(smile_map[r+1][col-1], smile_map[r][col-1]))
                
            elif r == nrows - 1:
                smile_map[r].append(smile_land[r][col] + max(smile_map[r][col-1], smile_map[r-1][col-1]))
                
            elif r > 0 and r < nrows - 1:
                smile_map[r].append(smile_land[r][col] + max(smile_map[r+1][col-1], smile_map[r][col-1], smile_map[r-1][col-1]))
                
        return smile_map
    
    def get_max_value_cell(row, col, smile_map):
        '''
        Returns the row of the left neighbor of the cell at loc = (row, col)
        '''
        if nrows == 1:
            return 0
        
        elif row == 0:
            possible_locs = [(row, col-1),(row+1, col-1)]
        elif row == nrows - 1:
            possible_locs = [(row, col-1),(row-1, col-1)]
        elif row > 0 and row < nrows - 1:
            possible_locs = [(row+1, col-1), (row, col-1), (row-1, col-1)]
        
        max_row = None
        max_val = 0
        for r, c in possible_locs:
            if smile_map[r][c] >= max_val:
                max_val = smile_map[r][c]
                max_row = r
        return max_row
    
    #Create a mapping where each cell represents cost of reaching from first
    #column to column of that cell
    smile_map = [[val[0]] for val in smile_land]
    for i in range(1, ncols):
        smile_map = update_map(smile_map, i)
    
    #Now, maximum value in the last column is the end of maximum happiness path
    #Trace this path from last column to first column. 
    col = [smile_map[row][-1] for row in range(nrows)]
    loc = col.index(max(col))
    path = [loc]
    for i in range(ncols-1, 0, -1):
        path.append(get_max_value_cell(path[-1], i, smile_map))
    
    #Path represents end to start. Reverse the result to represent it as start
    #to end.
    path.reverse()
    return path
    