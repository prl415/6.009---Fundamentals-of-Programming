# NO IMPORTS ALLOWED!

##################################################
### Problem 1: efficiency
##################################################

def unique(input_list):
     output = []
     seen = set()
     for item in input_list:
         if item not in seen:
             seen.add(item)
             output.append(item)
     return output

##################################################
### Problem 2: phone words
##################################################

allwords = set(open('words2.txt').read().splitlines())

def is_word(i):
    return i.lower() in allwords

key_letters = {
    '2': 'ABC',
    '3': 'DEF',
    '4': 'GHI',
    '5': 'JKL',
    '6': 'MNO',
    '7': 'PQRS',
    '8': 'TUV',
    '9': 'WXYZ',
}


def phone_words(digits):
    def helper(current_digits, current_word):
        if is_word(current_word):
            yield current_word
            
        if len(current_digits) == 0:
            return
            
        digit = current_digits[0]
        yield from helper(current_digits[1:], '')
        if digit in '01':
            return
        
        for letter in key_letters[digit]:
            yield from helper(current_digits[1:], current_word + letter)
    
    return set(helper(digits, ''))

##################################################
### Problem 3: radix trie
##################################################

from trie import Trie, RadixTrie


def dictify(t):
    """
    For debugging purposes.  Given a trie (or radix trie), return a dictionary
    representation of that structure, including the value and children
    associated with each node.
    """
    out = {'value': t.value, 'children': {}}
    for ch, child in t.children.items():
        out['children'][ch] = dictify(child)
    return out


def compress_trie(trie):
    new_trie = RadixTrie()
    
    def helper(trie_node, radix_node, word):
        #Base Cases
        #---------------------
        #Reached to a leaf
        if len(trie_node.children) == 0:
            radix_node.children[word] = RadixTrie()
            radix_node.children[word].value = trie_node.value
            return
        
        #Node with one child
        elif len(trie_node.children) == 1:
            #Value of the node is None, continue to pick up the letters
            if trie_node.value == None:
                (edge, child), = trie_node.children.items()
                helper(child, radix_node, word + edge)
                return
            
            #Value of the node is not None, if current node is not RadixTree
            #node, create a new node with current word
            else:
                if word == '':
                    radix_node.value = trie_node.value
                else:
                    radix_node.children[word] = RadixTrie()
                    radix_node = radix_node.children[word]
                    radix_node.value = trie_node.value
                    word = ''  
                (edge, child), = trie_node.children.items()
                helper(child, radix_node, word + edge)
                return    
        
        #Recursive Step
        #Radix_node is not root and has more than one child    
        else:
            if word != '':
                radix_node.children[word] = RadixTrie()
                radix_node = radix_node.children[word]
                radix_node.value = trie_node.value
                word = ''
            for edge, child in trie_node.children.items():
                helper(child, radix_node, word + edge)
            return
        
    helper(trie, new_trie, '')
    return new_trie