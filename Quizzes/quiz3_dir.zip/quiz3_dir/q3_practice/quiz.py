import sys
sys.setrecursionlimit(1000)

# NO OTHER IMPORTS!

############################################################
## Problem 1
############################################################

# Constant folding

def constant_fold(expr):
    """Simplify parts of the expression whose constant values we can predict in advance,
    according to the rules set out in the quiz document.

    >>> constant_fold(1)
    1
    >>> constant_fold('x')
    'x'
    >>> constant_fold(('+', 2, 3))
    5
    >>> constant_fold(('+', 'x', ('*', 8, 3)))
    ('+', 'x', 24)
    >>> constant_fold(('*', 'x', ('-', 8, 7)))
    'x'
    """
    pass

############################################################
## Problem 2
############################################################

# Databases

def select(table,which,filters=None,order_by=None):
    """select matching rows from the table
    result is a list containing the field values specifed by select in the order
    specified by order_by (or in table order if no order_by is specified).
    No row of table headers should be included.

    table is a list of rows, each row is a list of field values
      table[0] is a row of field names (strings)
      table[1:] are rows of data (can be any type)
      table has at least one row (ie, the field names)

    which is a sequence of field names specifing which data should
      be included in each returned row.  Must contain at least one field.

    filters, if specified, is a sequence of clauses of the form (pred, field_or_const, field_or_const)
      field has the form ['field_name'], const is a number or string
      pred is one of "=","!=","<","<=",">",">="
      if specified, row matches if all predicates evaluate to True
      if not specified, all rows match

    order_by, if specified is (field_name, asc_or_desc).
      asc_or_desc is either "asc" or "desc" for ascending or decending sort order
      if not specifed, return rows in table order"""
    pass
      
      
 

############################################################
## Problem 3
############################################################

# Infinite lists

