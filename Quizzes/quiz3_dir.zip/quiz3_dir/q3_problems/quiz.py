# NO IMPORTS!

#############
# Problem 1 #
#############

def count_viable(weights, capacity):
    """ Returns the number of viable sets of animals """
    pass


#############
# Problem 2 #
#############

def find_valid_ordering(class_graph):
    """ Returns a valid ordering of classes """
    pass


#############
# Problem 3 #
#############

class Class_DB(object):
    def __init__(self):
        self.schedule = dict()

def build_rep(default_db, update_db):
    """ Returns a representation of the information in default_db and update_db.
        This representation will be used to implement the other methods."""
    pass


def get_class_days(class_list, rep):
    """ Returns a list of lists class_dates where class_dates[i] is a list of all
        dates on which class_list[i] meets """
    pass


def get_late_classes(time, rep):
    """ Returns a list of all classes that never meet before the specified time """
    pass


#############
# Problem 4 #
#############




class TermRecords(object):
    """Track subjects and students through the term."""

    def __init__(self,records):
        """Initialize term from list of records.

        Each record has the following form:
            {"student": student, "subjects": [subject, subject, ...]}
        """
        pass


    def transcript(self,student_id):
        """Return list of subjects for which student is registered."""
        pass

    def classlist(self,subject):
        """Return list of students registered for `subject`."""
        pass

    def add(self,student_id,subject):
        """Specified student has added a `subject`.

        Should also handle the following cases:
        -- student didn't exist before
        -- subject didn't exist before
        -- student was already registered for subject
        """
        pass
    
    def drop(self,student_id,subject):
        """Specified student has dropped a subject.

        Should also handle the following cases:
        -- student doesn't exist
        -- subject doesn't exist
        -- student wasn't registered for subject
        """
        pass

    def too_many_subjects(self,limit):
        """Return list of students registered for more than `limit` subjects."""
        pass

    def enrollments(self):
        """Return list of (subject, # of registered students) for all subjects."""
        pass


    def taking_all(self,subject_list):
        """Return list of students taking *all* of the listed subjects."""
        pass
    
    def taking_some(self,subject_list):
        """Return list of students taking *at least one* of the listed subjects."""
        pass

    def better_together(self,N):
        """Return count of students who have at least n subjects in
        common with at least one other student."""
        pass
    
#############
# Problem 5 #
#############

def has_liberty(board,row,col,seen=None):
    """Return ``True`` if stone at intersection (`row`, `col`) has
    at least one liberty or if there is no stone at the
    intersection, ''False'' if the stone has no liberties."""
    pass


def capture(board,color):
    """Return updated `board` with all the captured stones of
    specified `color` removed."""
    pass


# handy test board
board= [
  '.bwwb',
  'bbwwb',
  'bwb.w',
  'bbwbw',
  'wbwwb'
]


#############
# Problem 6 #
#############

def count_straights(k, L, n):
    """
    Count the possible hands in k-Label Poker where
      k = # labels
      L = # levels, 1...L inclusive
      n = number cards in a hand

    """
    def check_straights(hand):
        pass





#############
# Problem 7 #
#############


def build_schedule_rep(default_db, update_db):
    for update in update_db:
        
        if update[0] == 'ADD':
            default_db.append(update[1:])
            
        elif update[0] == 'DELETE':
            try:
                default_db.remove(update[1:-1])
                default_db.append(update[1:-1] + ['-' + update[-1]])
            except:
                pass
            
    
    return default_db

def map_classes_to_buildings(rep):
    classes_to_buildings = dict()

    for meeting in rep:
        course = meeting[0]
        building = meeting[3]
        classes_to_buildings.setdefault(course, set()).add(building)

    return classes_to_buildings

def get_near_classes(buildings, rep):
    """
    OUTPUT: A list, in no particular order, of all classes that meet
    only in the list of buildings given by `buildings`.
    """
    classes_to_buildings = map_classes_to_buildings(rep)
    near_classes = []
    
    for course, course_location in classes_to_buildings.items():
        if set(buildings).intersection(course_location) == course_location:
            near_classes.append(course)
            
    return near_classes
    
def earliest_meeting(building, day_of_week, rep):
    """
    OUTPUT: An integer earliest time (hour, such as 9),
    the earliest meeting given by the combined database of classes,
    occurring on any week in `building` on `day_of_week`.
    If no meetings take place on `day_of_week` in that building on any
     week, return `None`.
    """
    earliest_time = float('inf')
    
    for meeting in rep:
        meeting_hour = int(meeting[1])
        meeting_day = meeting[2]
        meeting_building = meeting[3]
        
        if building == meeting_building and day_of_week == meeting_day:
            if earliest_time > meeting_hour:
                earliest_time = meeting_hour
                
    if earliest_time == float('inf'):
        return None
    
    return earliest_time

def classes_to_meeting_time(rep):
    classes_to_meeting = dict()
    
    for meeting in rep:
        course = meeting[0]
        if course == '3.091':
            print(meeting)
        if len(meeting) == 5:
            classes_to_meeting.setdefault(course, []).append(tuple(meeting[1:3] + [meeting[4]]))
        else:
            classes_to_meeting.setdefault(course, []).append(tuple(meeting[1:3]))
        
    return classes_to_meeting

def have_conflicts(class_list, rep):
    """
    OUTPUT: A Boolean (True/False) indicating whether any two classes
    in class_list conflict. Two classes conflict when they meet on the same day
    of the week during the same week at the same time.
    """
    classes_to_meeting_dates = classes_to_meeting_time(rep)
    
    for course1 in class_list:
        if course1 in classes_to_meeting_dates:    
            course1_meeting_dates = classes_to_meeting_dates[course1]
        else:
            continue
        
        if course1 in ["6.003", "6.03"]:
            print(course1, course1_meeting_dates)
        for course2 in set(class_list) - set([course1]):
            
            if course2 in classes_to_meeting_dates:    
                course2_meeting_dates = classes_to_meeting_dates[course2]
            else:
                continue
            
            if set(course1_meeting_dates).intersection(set(course2_meeting_dates)) != set([]):
                print('Conflict with: ', course1, course2)
                print('At: ', set(course1_meeting_dates).intersection(set(course2_meeting_dates)))
                print('Course1: ', course1_meeting_dates)
                print('Course2: ', course2_meeting_dates)
                print('\n')
                return True
    
    return False
                
    

