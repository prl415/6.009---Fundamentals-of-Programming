junctions = {'A', 'B'}

wires = {'0': ('A', 'B'), '1': ('A', 'B'), '2': ('A', 'B')}

resistances = {'0': 2, '1': 4, '2': 4}

voltages = {'0': 6, '1': 12, '2': 16}

currents = {'0': -2, '1': 0.5, '2': 1.5}

deviations = {'0': 0, '1': 8, '2': 0}

soln = 0.0

