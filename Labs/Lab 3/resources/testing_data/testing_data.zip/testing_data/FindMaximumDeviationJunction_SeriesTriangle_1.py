junctions = {'A', 'B', 'C'}

wires = {'0': ('A', 'B'), '1': ('B', 'C'), '2': ('C', 'A')}

resistances = {'0': 0, '1': 2, '2': 3}

voltages = {'0': 5, '1': 0, '2': 0}

currents = {'0': 1, '1': 2, '2': 1}

soln = {'B', 'C'}

