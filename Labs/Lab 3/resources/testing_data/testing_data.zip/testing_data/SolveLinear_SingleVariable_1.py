variables = {'x'}

equations = [{'x': 1, 1: 2}]

soln = {'x': -2}

