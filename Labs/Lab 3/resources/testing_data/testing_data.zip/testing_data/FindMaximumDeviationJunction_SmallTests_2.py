junctions = {'A', 'B'}

wires = {'0': ('A', 'B'), '1': ('A', 'B'), '2': ('A', 'B')}

resistances = {'0': 2, '1': 4, '2': 4}

voltages = {'0': 6, '1': 12, '2': 16}

currents = {'0': -2, '1': 1, '2': 1}

soln = {'A', 'B'}

