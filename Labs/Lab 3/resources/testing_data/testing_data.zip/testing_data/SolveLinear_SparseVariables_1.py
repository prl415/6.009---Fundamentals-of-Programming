variables = {'x', 'y'}

equations = [{'x': 1, 'y': 1, 1: 1}, {'x': 0, 'y': 2}]

soln = {'x': -1.0, 'y': 0.0}

