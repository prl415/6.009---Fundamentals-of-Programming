class LinkedRep:
    def __init__(self):
        self.students = []
        self.psets = []
        self.grades = []

    def addStudent(self, name, kerberos):
        student = {"name": name, "kerberos": kerberos}
        self.students.append(student)
        return student
    def addPset(self, number, points):
        pset = {"number": number, "points": points}
        self.psets.append(pset)
        return pset
    def addGrade(self, pset, student, points):
        grade = {"pset": pset, "student": student, "points": points}
        self.grades.append(grade)
        return grade

    def studentsWithName(self, name): # don't assume unique
        return [student for student in self.students
                if student["name"] == name]
    def studentWithKerberos(self, kerberos): # assume unique
        return [student for student in self.students
                if student["kerberos"] == kerberos][0]
    def psetWithNumber(self, number): # assume unique
        return [pset for pset in self.psets
                if pset["number"] == number][0]

    def pointsForPsetAndStudent(self, pset, student): # assume unique
        return [grade["points"] for grade in self.grades
                if grade["pset"] is pset and
                   grade["student"] is student][0]
    def gradesForStudent(self, student):
        return [grade for grade in self.grades
                if grade["student"] is student]
    def totalPointsForStudent(self, student):
        return sum(grade["points"]
                   for grade in self.gradesForStudent(student))
    def gradesForPset(self, pset):
        return [grade for grade in self.grades
                if grade["pset"] is pset]


class IDRep:
    def __init__(self):
        self.students = []
        self.psets = []
        self.grades = []
        self.nextId = 1

    def addStudent(self, name, kerberos):
        student = {"id": self.nextId, "name": name, "kerberos": kerberos}
        self.students.append(student)
        self.nextId += 1
        return student
    def addPset(self, number, points):
        pset = {"id": self.nextId, "number": number, "points": points}
        self.psets.append(pset)
        self.nextId += 1
        return pset
    def addGrade(self, pset, student, points):
        grade = {"id": self.nextId, "pset": pset["id"],
                 "student": student["id"], "points": points}
        self.grades.append(grade)
        self.nextId += 1
        return grade

    def studentsWithName(self, name): # don't assume unique
        return [student for student in self.students
                if student["name"] == name]
    def studentWithKerberos(self, kerberos): # assume unique
        return [student for student in self.students
                if student["kerberos"] == kerberos][0]
    def psetWithNumber(self, number): # assume unique
        return [pset for pset in self.psets
                if pset["number"] == number][0]

    def studentWithID(self, id): # assume unique
        return [student for student in self.students
                if student["id"] == id][0]
    def psetWithID(self, id): # assume unique
        return [pset for pset in self.psets
                if pset["id"] == id][0]
    # for good measure:
    def gradeWithID(self, id): # assume unique
        return [grade for grade in self.grades
                if grade["id"] == id][0]
    def expandGrade(self, grade):
        return dict(grade,
            pset = self.psetWithID(grade["pset"]),
            student = self.studentWithID(grade["student"]))

    def pointsForPsetAndStudent(self, pset, student): # assume unique
        return [grade["points"] for grade in self.grades
                if grade["pset"] == pset["id"] and
                   grade["student"] == student["id"]][0]
    def gradesForStudent(self, student):
        return [grade for grade in self.grades
                if grade["student"] == student["id"]]
    def totalPointsForStudent(self, student): # same as above
        return sum(grade["points"]
                   for grade in self.gradesForStudent(student))
    def gradesForPset(self, pset):
        return [grade for grade in self.grades
                if grade["pset"] == pset["id"]]


class IndexedLinkedRep:
    def __init__(self):
        self.students = []
        self.psets = []
        self.grades = []
        self.studentsByName = {}                                 #NEW
        self.studentByKerberos = {}                              #NEW
        self.psetByNumber = {}                                   #NEW

    def addStudent(self, name, kerberos):
        assert kerberos not in self.studentByKerberos # need unique
        student = {"name": name, "kerberos": kerberos}
        self.students.append(student)
        self.studentsByName.setdefault(name, []).append(student) #NEW
        self.studentByKerberos[kerberos] = student               #NEW
        return student
    def addPset(self, number, points):
        assert number not in self.psetByNumber # need unique
        pset = {"number": number, "points": points}
        self.psets.append(pset)
        self.psetByNumber[number] = pset                         #NEW
        return pset
    def addGrade(self, pset, student, points):
        grade = {"pset": pset, "student": student, "points": points}
        self.grades.append(grade)
        return grade

    def studentsWithName(self, name):
        return self.studentsByName.get(name, [])                 #NEW
    def studentWithKerberos(self, kerberos):
        return self.studentByKerberos[kerberos]                  #NEW
    def psetWithNumber(self, number):
        return self.psetByNumber[number]                         #NEW

    def changeStudentName(self, student, name):
        self.studentsByName[student["name"]].remove(student)
        student["name"] = name
        self.studentsByName.setdefault(name, []).append(student)
    def changeStudentKerberos(self, student, kerberos):
        del self.studentsByKerberos[student["kerberos"]]
        student["kerberos"] = kerberos
        self.studentsByKerberos[kerberos] = student


class IndexedIDRep:
    def __init__(self):
        self.students = []
        self.psets = []
        self.grades = []
        self.nextId = 1
        self.studentById = {}                                    #NEW
        self.studentsByName = {}                                 #NEW
        self.studentByKerberos = {}                              #NEW
        self.psetById = {}                                       #NEW
        self.psetByNumber = {}                                   #NEW
        self.gradeById = {}                                      #NEW

    def addStudent(self, name, kerberos):
        assert self.nextId not in self.studentById # should be unique
        assert kerberos not in self.studentByKerberos # need unique
        student = {"id": self.nextId, "name": name, "kerberos": kerberos}
        self.students.append(student)
        self.studentById[self.nextId] = student
        self.studentsByName.setdefault(name, []).append(student) #NEW
        self.studentByKerberos[kerberos] = student               #NEW
        self.nextId += 1
        return student
    def addPset(self, number, points):
        assert self.nextId not in self.studentById # should be unique
        assert number not in self.psetByNumber # need unique
        pset = {"id": self.nextId, "number": number, "points": points}
        self.psets.append(pset)
        self.psetById[self.nextId] = pset                        #NEW
        self.psetByNumber[number] = pset                         #NEW
        self.nextId += 1
        return pset
    def addGrade(self, pset, student, points):
        assert self.nextId not in self.gradeById # should be unique
        grade = {"id": self.nextId, "pset": pset["id"],
                 "student": student["id"], "points": points}
        self.grades.append(grade)
        self.gradeById[self.nextId] = grade                      #NEW
        self.nextId += 1
        return grade

    # Next three functions are identical to IndexedLinkedRep definitions above
    def studentsWithName(self, name): # don't assume unique
        return self.studentsByName.get(name, [])                 #NEW
    def studentWithKerberos(self, kerberos): # assume unique
        return self.studentByKerberos[kerberos]                  #NEW
    def psetWithNumber(self, number): # assume unique
        return self.psetByNumber[number]                         #NEW
    def studentWithID(self, id): # assume unique
        return self.studentById[id]                              #NEW
    def psetWithID(self, id): # assume unique
        return self.psetById[id]                                 #NEW
    def gradeWithID(self, id): # assume unique
        return self.gradeById[id]                                #NEW
    def expandGrade(self, grade): # as before
        return dict(grade,
            pset = self.psetWithID(grade["pset"]),
            student = self.studentWithID(grade["student"]))

    # Next two functions are identical to IndexedLinkedRep definitions above
    def changeStudentName(self, student, name):
        self.studentsByName[student["name"]].remove(student)
        student["name"] = name
        self.studentsByName.setdefault(name, []).append(student)
    def changeStudentKerberos(self, student, kerberos):
        del self.studentsByKerberos[student["kerberos"]]
        student["kerberos"] = kerberos
        self.studentsByKerberos[kerberos] = student


class IndexedLinkedRep1(IndexedLinkedRep):
    def __init__(self):
        super().__init__()
        self.gradeByPsetAndStudent = {}
    def addGrade(self, pset, student, points):
        grade = super().addGrade(pset, student, points)
        self.gradeByPsetAndStudent[id(pset), id(student)] = grade
        return grade
    def pointsForPsetAndStudent(self, pset, student): # assume unique
        return self.gradeByPsetAndStudent[id(pset), id(student)]["points"]

class IndexedIDRep1(IndexedIDRep):
    def __init__(self):
        super().__init__()
        self.gradeByPsetAndStudent = {}
    def addGrade(self, pset, student, points):
        grade = super().addGrade(pset, student, points)
        self.gradeByPsetAndStudent[pset["id"], student["id"]] = grade
        return grade
    def pointsForPsetAndStudent(self, pset, student): # assume unique
        return self.gradeByPsetAndStudent[pset["id"], student["id"]]["points"]


class IndexedLinkedRep2(IndexedLinkedRep1):
    def __init__(self):
        super().__init__()
        self.gradesByStudent = {}
        self.gradesByPset = {}
    def addGrade(self, pset, student, points):
        grade = super().addGrade(pset, student, points)
        self.gradesByStudent.setdefault(id(student), []).append(grade)
        self.gradesByPset.setdefault(id(pset), []).append(grade)
        return grade
    def gradesForStudent(self, student):
        return self.gradesByStudent[id(student)]
    def gradesForPset(self, pset):
        return self.gradesByPset[id(pset)]

class IndexedIDRep2(IndexedIDRep1):
    def __init__(self):
        super().__init__()
        self.gradesByStudent = {}
        self.gradesByPset = {}
    def addGrade(self, pset, student, points):
        grade = super().addGrade(pset, student, points)
        self.gradesByStudent.setdefault(student["id"], []).append(grade)
        self.gradesByPset.setdefault(pset["id"], []).append(grade)
        return grade
    def gradesForStudent(self, student):
        return self.gradesByStudent[student["id"]]
    def gradesForPset(self, pset):
        return self.gradesByPset[pset["id"]]


class NestedIndexedLinkedRep(IndexedLinkedRep1):
    def addStudent(self, name, kerberos):
        student = super().addStudent(name, kerberos)
        student["grades"] = []
        return student
    def addPset(self, number, points):
        pset = super().addPset(number, points)
        pset["grades"] = []
        return pset
    def addGrade(self, pset, student, points):
        grade = super().addGrade(pset, student, points)
        student["grades"].append(grade)
        pset["grades"].append(grade)
        return grade
    def gradesForStudent(self, student):
        return student["grades"]
    def gradesForPset(self, pset):
        return pset["grades"]
    
class NestedIndexedIDRep(IndexedIDRep1):
    def addStudent(self, name, kerberos): # same
        student = super().addStudent(name, kerberos)
        student["grades"] = []
        return student
    def addPset(self, number, points): # same
        pset = super().addPset(number, points)
        pset["grades"] = []
        return pset
    def addGrade(self, pset, student, points):
        grade = super().addGrade(pset, student, points)
        student["grades"].append(grade["id"])
        pset["grades"].append(grade["id"])
        return grade
    def gradesForStudent(self, student):
        return [self.gradeWithID(id) for id in student["grades"]]
    def gradesForPset(self, pset):
        return [self.gradeWithID(id) for id in pset["grades"]]


class AllNestedIndexedLinkedRep(IndexedLinkedRep):
    def addStudent(self, name, kerberos):
        student = super().addStudent(name, kerberos)
        student["grades"] = {}                          #NEW
        return student
    def addPset(self, number, points):
        pset = super().addPset(number, points)
        pset["grades"] = {}                             #NEW
        return pset
    def addGrade(self, pset, student, points):
        grade = super().addGrade(pset, student, points)
        student["grades"][id(pset)] = grade             #NEW
        pset["grades"][id(student)] = grade             #NEW
        return grade
    def pointsForPsetAndStudent(self, pset, student):
        return pset["grades"][id(student)]["points"]    #NEW
        #or: student["grades"][id(pset)]
    def gradesForStudent(self, student):
        return list(student["grades"].values())         #NEW
    def gradesForPset(self, pset):
        return list(pset["grades"].values())            #NEW
    
class AllNestedIndexedIDRep(IndexedIDRep):
    def addStudent(self, name, kerberos): # same
        student = super().addStudent(name, kerberos)
        student["grades"] = {}
        return student
    def addPset(self, number, points): # same
        pset = super().addPset(number, points)
        pset["grades"] = {}
        return pset
    def addGrade(self, pset, student, points):
        grade = super().addGrade(pset, student, points)
        student["grades"][pset["id"]] = grade["id"]     #NEW
        pset["grades"][student["id"]] = grade["id"]     #NEW
        return grade
    def pointsForPsetAndStudent(self, pset, student):
        return self.gradeWithID(pset["grades"][student["id"]])["points"] #NEW
        #or: self.gradeWithID(student["grades"][pset["id"]])["points"]
    def gradesForStudent(self, student):
        return [self.gradeWithID(id)
                for id in student["grades"].values()]   #NEW
    def gradesForPset(self, pset):
        return [self.gradeWithID(id)
                for id in pset["grades"].values()]      #NEW


class IndexedLinkedRep3(IndexedLinkedRep2):
    def __init__(self):
        super().__init__()
        self.totalPointsByStudent = {}
    def addStudent(self, name, kerberos):
        student = super().addStudent(name, kerberos)
        self.totalPointsByStudent[id(student)] = 0
        return student
    def addGrade(self, pset, student, points):
        grade = super().addGrade(pset, student, points)
        self.totalPointsByStudent[id(student)] += points
        return grade
    def totalPointsForStudent(self, student):
        return self.totalPointsByStudent[id(student)]

class AllNestedIndexedLinkedRep3(AllNestedIndexedLinkedRep):
    def addStudent(self, name, kerberos):
        student = super().addStudent(name, kerberos)
        student["totalPoints"] = 0
        return student
    def addGrade(self, pset, student, points):
        grade = super().addGrade(pset, student, points)
        student["totalPoints"] += points
        return grade
    def totalPointsForStudent(self, student):
        return student["totalPoints"]


def example(Rep):
    r = Rep()
    r.addStudent("Alice", "al1ce")
    r.addStudent("Bob", "b0b")
    r.addPset(1, 10)
    r.addPset(2, 15)
    r.addGrade(r.psetWithNumber(1), r.studentWithKerberos("al1ce"), 9.5)
    r.addGrade(r.psetWithNumber(1), r.studentWithKerberos("b0b"), 6)
    r.addGrade(r.psetWithNumber(2), r.studentWithKerberos("b0b"), 12)
    return r

if __name__ == "__main__":
    for Rep in [LinkedRep, IDRep, IndexedLinkedRep, IndexedIDRep,
            IndexedLinkedRep1, IndexedIDRep1, IndexedLinkedRep2, IndexedIDRep2,
            NestedIndexedLinkedRep, NestedIndexedIDRep,
            AllNestedIndexedLinkedRep, AllNestedIndexedIDRep,
            IndexedLinkedRep3, AllNestedIndexedLinkedRep3]:
        r = example(Rep)
        assert r.studentsWithName("Bob") == [r.studentWithKerberos("b0b")]
        if hasattr(Rep, "pointsForPsetAndStudent"):
            assert r.pointsForPsetAndStudent(r.psetWithNumber(1),
                r.studentWithKerberos("al1ce")) == 9.5
        if hasattr(Rep, "changeStudentName"):
            r.changeStudentName(r.studentWithKerberos("b0b"), "Robert")
            assert len(r.studentsWithName("Robert")) == 1
        if hasattr(Rep, "totalPointsForStudent"):
            assert r.totalPointsForStudent(r.studentWithKerberos("al1ce")) == 9.5
            assert r.totalPointsForStudent(r.studentWithKerberos("b0b")) == 18
    print("All tests passed.")
