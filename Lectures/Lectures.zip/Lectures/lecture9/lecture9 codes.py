# -*- coding: utf-8 -*-
"""
Created on Mon Sep  7 01:41:45 2020

@author: Mustafa
"""
#import json
#
#student1 = {"id": 90001, "name": "Alice"}
#student2 = {"id": 90002, "name": "Bob"}
#major1 = {"num": 42, "name": "Blah Blah Studies",
#          "students": [student1, student2]}
#print(student1["name"])
#print(" and ".join(student["name"] for student in major1["students"]))
#
#from urllib.request import urlopen
#data = urlopen("https://dog.ceo/api/breeds/image/random").read()
#url = json.loads(data)["message"]
#from IPython.display import Image

class a:
    def __init__(self):
        self.b = 1
        self.c = 2
    
class d(a):
    def __init__(self):
        super().__init__()
        self.e = 5
        
        