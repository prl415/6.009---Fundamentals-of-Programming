# Recursive strategy to solve the Dinner / MIS Problem


LargeGuestList = ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I']
LargeDislikes = [['B', 'C'], ['C', 'D'], ['D', 'E'], ['F','G'],
                 ['F', 'H'], ['F', 'I'], ['G', 'H']]


def independent(chosen, badPairs):
    """Are the chosen vertices independent, avoiding all bad pairs?"""
    for a, b in badPairs:
        if a in chosen and b in chosen:
            return False
    return True


def MIS(vertices, edges, chosen = [], best = []):
    """Find a maximum independent set in a given graph.
    vertices is a list of vertices still available to be chosen.
    edges is a list of pairs of vertices that should not be chosen together.
    chosen is the list of currently chosen vertices in backtracking search.
    best is the best solution found so far.
    """
    if len(vertices) == 0:
        if len(chosen) > len(best):
            best = chosen
        return best
    if independent(chosen + [vertices[0]], edges):
        best = MIS(vertices[1:], edges, chosen + [vertices[0]], best)
    return MIS(vertices[1:], edges, chosen, best)

    
print(MIS(LargeGuestList, LargeDislikes))
