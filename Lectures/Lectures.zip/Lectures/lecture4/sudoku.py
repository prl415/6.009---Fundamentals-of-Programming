# Given a partially filled in Sudoku board, complete the puzzle
# obeying the rules of Sudoku

# This code fills in the missing squares of a Sudoku puzzle
# obeying the Sudoku rules through brute-force guessing and checking.


# Global variable for counting backtracks
backtracks = 0


def findNextCellToFill(grid):
    """Find coordinates of an empty cell in a Sudoku grid,
    or return -1, -1 if there are no empty cells."""
    for x in range(0, 9):
        for y in range(0, 9):
            if grid[x][y] == 0:
                return x, y
    return -1, -1


def isValid(grid, i, j, e):
    """Would setting grid[i,j] = e satisfy all Sudoku constraints?"""
    rowOk = all([e != grid[i][x] for x in range(9)])
    if rowOk:
        columnOk = all([e != grid[x][j] for x in range(9)])
        if columnOk:
            #finding the top left x,y co-ordinates of
            #the section or sub-grid containing the i,j cell
            secTopX, secTopY = 3 *(i//3), 3 *(j//3)
            for x in range(secTopX, secTopX+3):
                for y in range(secTopY, secTopY+3):
                    if grid[x][y] == e:
                        return False
            return True
    return False

def solveSudoku(grid):
    """Try to solve a Sudoku puzzle in-place, and return whether successful.
    grid is a list of lists of integers between 0 and 9, where 0 means unfilled,
    and each top-level list corresponds to a row of 9 cells."""

    global backtracks

    #find the next empty cell to fill
    i, j = findNextCellToFill(grid)
    if i == -1: # no more empty cells
        return True

    for e in range(1, 10):
        #Try different values in i, j location
        if isValid(grid, i, j, e):
            grid[i][j] = e
            if solveSudoku(grid):
                return True
            
            #Undo the current cell for backtracking
            backtracks += 1
    grid[i][j] = 0

    return False


def printSudoku(grid):
    numrow = 0
    for row in grid:
        if numrow % 3 == 0 and numrow != 0:
            print (' ')
        print (row[0:3], ' ', row[3:6], ' ', row[6:9])
        numrow += 1       
    return

input = [[5,1,7,6,0,0,0,3,4],
         [2,8,9,0,0,4,0,0,0],
         [3,4,6,2,0,5,0,9,0],
         [6,0,2,0,0,0,0,1,0],
         [0,3,8,0,0,6,0,4,7],
         [0,0,0,0,0,0,0,0,0],
         [0,9,0,0,0,0,0,7,8],
         [7,0,3,4,0,0,5,6,0],
         [0,0,0,0,0,0,0,0,0]]

medium = [[5,1,7,6,0,0,0,3,4],
          [0,8,9,0,0,4,0,0,0],
          [3,0,6,2,0,5,0,9,0],
          [6,0,0,0,0,0,0,1,0],
          [0,3,0,0,0,6,0,4,7],
          [0,0,0,0,0,0,0,0,0],
          [0,9,0,0,0,0,0,7,8],
          [7,0,3,4,0,0,5,6,0],
          [0,0,0,0,0,0,0,0,0]]

hard  = [[8,5,0,0,0,2,4,0,0],
         [7,2,0,0,0,0,0,0,9],
         [0,0,4,0,0,0,0,0,0],
         [0,0,0,1,0,7,0,0,2],
         [3,0,5,0,0,0,9,0,0],
         [0,4,0,0,0,0,0,0,0],
         [0,0,0,0,8,0,0,7,0],
         [0,1,7,0,0,0,0,0,0],
         [0,0,0,0,3,6,0,4,0]]

diff  = [[0,0,5,3,0,0,0,0,0],
         [8,0,0,0,0,0,0,2,0],
         [0,7,0,0,1,0,5,0,0],
         [4,0,0,0,0,5,3,0,0],
         [0,1,0,0,7,0,0,0,6],
         [0,0,3,2,0,0,0,8,0],
         [0,6,0,5,0,0,0,0,9],
         [0,0,4,0,0,0,0,3,0],
         [0,0,0,0,0,9,7,0,0]]


backtracks = 0
print(solveSudoku(input))
printSudoku(input)
print()
print('Backtracks = ', backtracks)

backtracks = 0
print(solveSudoku(medium))
printSudoku(medium)
print()
print('Backtracks = ', backtracks)

backtracks = 0
print(solveSudoku(hard))
printSudoku(hard)
print()
print('Backtracks = ', backtracks)

backtracks = 0
print(solveSudoku(diff))
printSudoku(diff)
print()
print('Backtracks = ', backtracks)
