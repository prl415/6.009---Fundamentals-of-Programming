# Given a partially filled in Sudoku board, complete the puzzle
# obeying the rules of Sudoku

# Extra Optimization:
# Keep making implications until you cannot find any more implications.


# Global variable for counting backtracks
backtracks = 0

# i varies from entry[0] to entry[1] - 1, j varies from entry[2] to entry[3] - 1
sectors = [ [0, 3, 0, 3], [3, 6, 0, 3], [6, 9, 0, 3],
            [0, 3, 3, 6], [3, 6, 3, 6], [6, 9, 3, 6],
            [0, 3, 6, 9], [3, 6, 6, 9], [6, 9, 6, 9] ]

def findNextCellToFill(grid):
    """Find coordinates of an empty cell in a Sudoku grid,
    or return -1, -1 if there are no empty cells."""
    for x in range(0, 9):
        for y in range(0, 9):
            if grid[x][y] == 0:
                return x,y
    return -1,-1

def isValid(grid, i, j, e):
    """Would setting grid[i,j] = e satisfy all Sudoku constraints?"""
    rowOk = all([e != grid[i][x] for x in range(9)])
    if rowOk:
        columnOk = all([e != grid[x][j] for x in range(9)])
        if columnOk:
            #finding the top left x,y co-ordinates of
            #the section or sub-grid containing the i,j cell
            secTopX, secTopY = 3 *(i//3), 3 *(j//3)
            for x in range(secTopX, secTopX+3):
                for y in range(secTopY, secTopY+3):
                    if grid[x][y] == e:
                        return False
            return True
    return False


#This procedure makes implications based on existing numbers on squares
def makeImplications(grid, i, j, e):
    grid[i][j] = e
    impl = [(i, j, e)]

    done = False

    #Keep going till you stop finding implications
    while not done:
        done = True

        for sector in sectors:
            sectblanks = []

            #find missing elements in ith sector
            vset = {1, 2, 3, 4, 5, 6, 7, 8, 9}
            for x in range(sector[0], sector[1]):
                for y in range(sector[2], sector[3]):
                    if grid[x][y] != 0:
                        vset.remove(grid[x][y])

            #attach copy of vset to each missing square in ith sector
            for x in range(sector[0], sector[1]):
                for y in range(sector[2], sector[3]):
                    if grid[x][y] == 0:
                        sectblanks.append([x, y, vset.copy()])
            
            for blankx, blanky, left in sectblanks:
                #find the set of elements on the row corresponding to m and remove them
                rowv = set(grid[blankx][y] for y in range(9))
                left = left.difference(rowv)
                
                #find the set of elements on the column corresponding to m and remove them
                colv = set(grid[x][blanky] for x in range(9))
                left = left.difference(colv)
                             
                #check if the vset is a singleton
                if len(left) == 1:
                    val = left.pop()
                    if isValid(grid, blankx, blanky, val):
                        grid[blankx][blanky] = val
                        impl.append((blankx, blanky, val))
                        done = False
                
    return impl

def undoImplications(grid, impl):
    """Reset all implied grid cells listed in impl to 0"""
    for i, j, e in impl:
        grid[i][j] = 0

def solveSudokuMoreOpt(grid):
    """Try to solve a Sudoku puzzle in-place, and return whether successful.
    grid is a list of lists of integers between 0 and 9, where 0 means unfilled,
    and each top-level list corresponds to a row of 9 cells."""

    global backtracks

    #find the next empty cell to fill
    i, j = findNextCellToFill(grid)
    if i == -1:
        return True

    for e in range(1, 10):
        #Try different values in i, j location
        if isValid(grid, i, j, e):

            impl = makeImplications(grid, i, j, e)
            
            if solveSudokuMoreOpt(grid):
                return True
            #Undo the current cell for backtracking
            backtracks += 1
            undoImplications(grid, impl)

    return False

def printSudoku(grid):
    numrow = 0
    for row in grid:
        if numrow % 3 == 0 and numrow != 0:
            print (' ')
        print (row[0:3], ' ', row[3:6], ' ', row[6:9])
        numrow += 1       
    return

input = [[5,1,7,6,0,0,0,3,4],
         [2,8,9,0,0,4,0,0,0],
         [3,4,6,2,0,5,0,9,0],
         [6,0,2,0,0,0,0,1,0],
         [0,3,8,0,0,6,0,4,7],
         [0,0,0,0,0,0,0,0,0],
         [0,9,0,0,0,0,0,7,8],
         [7,0,3,4,0,0,5,6,0],
         [0,0,0,0,0,0,0,0,0]]

medium = [[5,1,7,6,0,0,0,3,4],
          [0,8,9,0,0,4,0,0,0],
          [3,0,6,2,0,5,0,9,0],
          [6,0,0,0,0,0,0,1,0],
          [0,3,0,0,0,6,0,4,7],
          [0,0,0,0,0,0,0,0,0],
          [0,9,0,0,0,0,0,7,8],
          [7,0,3,4,0,0,5,6,0],
          [0,0,0,0,0,0,0,0,0]]

hard  = [[8,5,0,0,0,2,4,0,0],
         [7,2,0,0,0,0,0,0,9],
         [0,0,4,0,0,0,0,0,0],
         [0,0,0,1,0,7,0,0,2],
         [3,0,5,0,0,0,9,0,0],
         [0,4,0,0,0,0,0,0,0],
         [0,0,0,0,8,0,0,7,0],
         [0,1,7,0,0,0,0,0,0],
         [0,0,0,0,3,6,0,4,0]]

diff  = [[0,0,5,3,0,0,0,0,0],
         [8,0,0,0,0,0,0,2,0],
         [0,7,0,0,1,0,5,0,0],
         [4,0,0,0,0,5,3,0,0],
         [0,1,0,0,7,0,0,0,6],
         [0,0,3,2,0,0,0,8,0],
         [0,6,0,5,0,0,0,0,9],
         [0,0,4,0,0,0,0,3,0],
         [0,0,0,0,0,9,7,0,0]]

backtracks = 0
print(solveSudokuMoreOpt(input))
printSudoku(input)
print()
print('Backtracks = ', backtracks)

backtracks = 0
print(solveSudokuMoreOpt(medium))
printSudoku(medium)
print()
print('Backtracks = ', backtracks)

backtracks = 0
print(solveSudokuMoreOpt(hard))
printSudoku(hard)
print()
print('Backtracks = ', backtracks)

backtracks = 0
print(solveSudokuMoreOpt(diff))
printSudoku(diff)
print()
print('Backtracks = ', backtracks)
