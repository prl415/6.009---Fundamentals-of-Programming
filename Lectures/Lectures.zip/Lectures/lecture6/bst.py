class Missing: pass

class BST:
    def __init__(self, key, value=None, left=None, right=None):
        self.key = key
        self.value = value
        self.left = left
        self.right = right

    def __str__(self):
        def recurse(node, prefix):
            if node is None:
                return f"{prefix}None\n"
            else:
                return f"{prefix}{node.key}: {node.value}\n" + \
                    recurse(node.left, prefix + '  ') + \
                    recurse(node.right, prefix + '  ')
        return recurse(self, '')
    def __repr__(self):
        """Short format for node that doesn't recurse.
        This gets called by tuple.__str__, for example."""
        return f"<BST {self.key}: {self.value}>"

    def get(self, key, missing=None):
        """Get the value associated with given key,
        or if key isn't there, return missing."""
        node = self
        while node is not None:
            if key == node.key:
                return node.value
            elif key < node.key:
                node = node.left
            else: # key > node.key
                node = node.right
        # node is None, so didn't find key
        return missing

    def path(self, key):
        """Return a list of node values visited along the way to find key"""
        values = []
        node = self
        while node is not None:
            values.append(node.value)
            if key == node.key:
                return values
            elif key < node.key:
                node = node.left
            else: # key > node.key
                node = node.right
        # node is None, so didn't find key
        values.append(None)
        return values

    def nearby(self, key):
        """Find a node containing the key, or if it's not present,
        either the next smaller key or the next larger key."""
        node = self
        while True:
            if key == node.key:
                node.value = value
                return node, "exact"
            elif key < node.key:
                if node.left is None:
                    return node, "larger"
                node = node.left
            else: # key > node.key:
                if node.right is None:
                    return node, "smaller"
                node = node.right

    def insert(self, key, value):
        """Add node with specified key and value into BST,
        or overwrite existing node with specified key,
        and return the node."""
        node = self
        while True:
            if key == node.key:
                node.value = value
                return node
            elif key < node.key:
                if node.left is None:
                    node.left = BST(key, value)
                    return node.left
                node = node.left
            else: # key > node.key:
                if node.right is None:
                    node.right = BST(key, value)
                    return node.right
                node = node.right

    def delete(self, key, parent=None):
        """Delete node with specified key, if there is one.
        Return whether a node was deleted."""
        node = self
        while node is not None:
            if key == node.key:
                break
            else:
                parent = node
                if key < node.key:
                    node = node.left
                else: # key > node.key:
                    node = node.right
        if node is None: # key not found
            return False
        
        if node.right is None:
            # Case 1: no right child.
            # We either have a left child or not, and link our parent there.
            if parent.left is node:
                parent.left = node.left
            elif parent.right is node:
                parent.right = node.left
        else:
            # Case 2: right child.
            # Find the very next key, called the successor.
            parent = node
            successor = node.right
            while successor.left is not None:
                parent = successor
                successor = successor.left
            # Replace node's data with successor's data.
            node.key = successor.key
            node.value = successor.value
            # Now delete the successor node, recursively.
            successor.delete(successor.key, parent)

        return True # key found and deleted

    def __contains__(self, key):
        # Use unique Missing value to detect absent key
        # (as opposed to a key with an associated value of None)
        value = self.get(key, Missing)
        return value is not Missing
    def __getitem__(self, key):
        value = self.get(key, Missing)
        if value is Missing:
            raise KeyError(key)
        else:
            return value
    def __setitem__(self, key, value):
        self.insert(key, value)
    def __delitem__(self, key): # dict iterface
        if not self.delete(key):
            raise KeyError(key)

    def print_in_order(self):
        """Print all (key, value) pairs in order by key"""
        if self.left is not None:
            self.left.print_in_order()
        print(f"{self.key}: {self.value}")
        if self.right is not None:
            self.right.print_in_order()

    def items(self):
        """Return a list of (key, value) pairs in order by key"""
        items = []
        def recurse(node):
            if node is None: return
            recurse(node.left)
            items.append((node.key, node.value))
            recurse(node.right)
        recurse(self)
        return items

    def __iter__(self): # generator
        """Return an iterator of (key, value) pairs in order by key"""
        if self.left is not None:
            yield from self.left
        yield (self.key, self.value)
        if self.right is not None:
            yield from self.right

def example():
    return BST(5, 'D',
        BST(3, 'B',
           BST(1, 'A'),
           BST(4, 'C')
        ),
        BST(11, 'F',
           BST(9, 'E'),
           BST(23, 'G')
        )
    )

if __name__ == '__main__':
    tree = example()
    print(tree)

    print('* INSERTING 10: Z')
    tree[10] = 'Z'
    print(tree)

    print('* DELETING 5')
    del tree[5]
    print(tree)
