# MERGE SORT: Recursive Divide-and-Conquer algorithm

def merge_sort(L, indent=1):
    """Returns a new sorted list containing the same elements as L."""
    print('.'*(indent-1), 'SORTING', L)

    # Base case: less than 2 elements, so already sorted
    if len(L) < 2:
        return L[:] # Makes a fresh copy of L, just in case the caller mutates L later.

    # Split L into two lists of approximately equal lengths.  (They might be off by one.)
    middle = len(L)//2
    left = L[:middle]
    right = L[middle:]
    print('.'*indent, 'SPLIT into', left, 'and', right)
        
    # Sort the two sides.
    left = merge_sort(left, indent+1)
    right = merge_sort(right, indent+1)
    print('.'*indent, 'SORTED into', left, 'and', right)
        
    # Merge the results.
    merged = merge(left, right)
    print('.'*indent, 'MERGED into', merged)
    return merged

def merge(left, right):
    """Assumes left and right are sorted lists.  Returns a single new
    list built, in order, from the elements of left and right."""

    result = []
    left_i = right_i = 0  # indices into left and right, respectively
    
    # Loop while there are elements in both lists.
    while left_i < len(left) and right_i < len(right):
        # Copy smallest element to result.
        if left[left_i] < right[right_i]:
            result.append(left[left_i])
            left_i += 1
        else:
            result.append(right[right_i])
            right_i += 1

    # Copy over any remaining elements.
    # Only one of the lists has any elements remaining!
    result.extend(left[left_i:]) # Recall that extend adds all elements of the argument list.
    result.extend(right[right_i:])
    return result

assert merge([1, 2], [3, 4]) == [1, 2, 3, 4]
assert merge([1, 3], [2, 4]) == [1, 2, 3, 4]
assert merge_sort([1, 4, 7, 3]) == [1, 3, 4, 7]
assert merge_sort([23, 3, 45, 7, 6, 11, 14, 12]) == [3, 6, 7, 11, 12, 14, 23, 45]
