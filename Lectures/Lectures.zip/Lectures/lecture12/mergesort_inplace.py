# IN-PLACE MERGE SORT: Doubly Recursive Divide-and-Conquer algorithm

def inplace_merge_sort(L, left=0, right=None, indent=1):
    """Sorts L[left:right] in place, defaulting to all of L."""
    if right is None: right = len(L)
    print('.'*(indent-1), 'SORTING', L[left:right])

    # Base case: less than 2 elements, so already sorted
    if right - left < 2: return
    
    # Split L into two lists of approximately equal lengths.  (They might be off by one.)
    middle = (left + right) // 2
    print('.'*indent, 'SPLIT into', L[left:middle], 'and', L[middle:right])
        
    # Sort the two sides.
    inplace_merge_sort(L, left, middle, indent+1)
    inplace_merge_sort(L, middle, right, indent+1)
    print('.'*indent, 'SORTED into', L[left:middle], 'and', L[middle:right])
        
    # Merge the results.
    inplace_merge(L, left, middle, right, '.'*indent)
    print('.'*indent, 'MERGED into', L[left:right])

def inplace_merge(L, left, middle, right, prefix = ''):
    """Merge sorted L[left:middle] and sorted L[middle:right]
    into sorted L[left:right]."""
    prefix += ':'
    print(f'{prefix} MERGE {L[left:middle]} AND {L[middle:right]} WITHIN {L}')
    # Base case: no elements in left part L[left:middle]
    if middle - left < 1: return
    # Base case: no elements in right part L[middle:right]
    if right - middle < 1: return
    # Recursive case.
    # Repeatedly move index left_i left in left part and
    # correspondingly move index right_i right in right part,
    # until we find L[left_i] <= L[right_i],
    # or we fall off left or right edge.
    left_i = middle - 1
    right_i = middle
    while left_i >= left and right_i < right and L[left_i] > L[right_i]:
        left_i -= 1
        right_i += 1
    # Move indices back one so that L[left_i] > L[right_i]
    # and this is the last such index.
    left_i += 1
    right_i -= 1
    # If left index hits left edge, check for more small elements on right.
    if left_i == left:
        while right_i < right and L[left_i] > L[right_i]:
            right_i += 1
        right_i -= 1  # fix overshoot
    # If right index hits right edge, check for more big elements on left.
    if right_i == right - 1:
        while left_i >= left and L[left_i] > L[right_i]:
            left_i -= 1
        left_i += 1  # fix overshoot
    # Now swap L[left_i:middle] with L[middle:right_i+1]
    big_swap(L, left_i, middle, right_i + 1, prefix)
    # Finally we can recurse.
    inplace_merge(L, left, left_i, middle, prefix)
    inplace_merge(L, middle, right_i + 1, right, prefix)

def big_swap(L, left, middle, right, prefix = ''):
    """Swap L[left:middle] with L[middle:right]"""
    print(f'{prefix}* SWAP {L[left:middle]}, {L[middle:right]} WITHIN {L}')
    # Base case: no elements in left part L[left:middle]
    if middle - left < 1: return
    # Base case: no elements in right part L[middle:right]
    if right - middle < 1: return
    # Recursive case.
    if middle <= (left + right) // 2:
        for i in range(left, middle):
            j = i + (middle - left)
            # Swap L[i] and L[j]
            L[i], L[j] = L[j], L[i]
        big_swap(L, middle, middle + (middle - left), right, prefix)
    else:
        for j in reversed(range(middle, right)):
            i = j - (right - middle)
            # Swap L[i] and L[j]
            L[i], L[j] = L[j], L[i]
        big_swap(L, left, middle - (right - middle), middle, prefix)

# Lots of testing of big_swap
for n in range(1, 10):
    for middle in range(n):
        L = list(range(n))
        big_swap(L, 0, middle, n)
        print(L, '==', list(range(middle, n)) + list(range(0, middle)))
        assert L == list(range(middle, n)) + list(range(0, middle))

L = [10, 15, 19, 23, 26, 32, 4, 9, 16, 30, 39, 47]
inplace_merge(L, 0, 6, 12)
assert L == [4, 9, 10, 15, 16, 19, 23, 26, 30, 32, 39, 47]

L = [1, 4, 7, 3]
inplace_merge_sort(L)
assert L == [1, 3, 4, 7]

L = [23, 3, 45, 7, 6, 11, 14, 12]
inplace_merge_sort(L)
assert L == [3, 6, 7, 11, 12, 14, 23, 45]
