# (IN-PLACE) QUICKSORT: Recursive Divide-and-Conquer algorithm

def quicksort(L, left = 0, right = None, depth = 1):
    """Sorts L[left:right] in place, defaulting to all of L."""
    if right is None: right = len(L)
    print('.'*depth, 'QUICKSORT', L[left:right])
    # Base case: less than 2 elements, so already sorted
    if right - left < 2: return
    # Recursive case: at least 2 elements
    # Partition L[left:right] into L[left:middle], L[middle], and L[middle+1:right]
    middle = partition(L, left, right)
    print('.'*depth, f'PARTITIONED INTO {L[left:middle]}, {L[middle]}, {L[middle+1:right]}')
    # Recursively sort L[left:middle]
    quicksort(L, left, middle, depth+1)
    # Recursively sort L[middle+1:right]
    quicksort(L, middle+1, right, depth+1)
    print('.'*depth, 'SORTED INTO', L[left:right])

def partition(L, left, right):
    """Partitions L[left:right] into L[left:middle], L[middle], and L[middle+1:right]
    according to the last element L[right-1] as pivot."""
    # Use the last element as the pivot, and conceptually remove it from L.
    pivot_i = right-1
    pivot = L[pivot_i]
    right -= 1
    # Walk through the array
    i = left
    while i < right:
        print(L[left:i], L[i], L[i+1:right], L[right:pivot_i], L[pivot_i])
        if L[i] <= pivot:
            # If we find an element < pivot, keep it where it is.
            # In this case, we just advance i.
            i += 1
        else:
            # If we find an element > pivot, move it to the end
            # by swapping with the last element of the array.
            L[i], L[right-1] = L[right-1], L[i]
            # In this case, we don't advance i, because we still need
            # to process the swapped element, but we shrink the array.
            right -= 1
    # At the end, i will be the first element > pivot.
    # Put the pivot there by swapping with its current position,
    # which is the end of the array.
    print(L[left:i], L[i] if i < pivot_i else None, L[i+1:pivot_i], L[pivot_i])
    L[i], L[pivot_i] = L[pivot_i], L[i]
    print(L[left:i], L[i], L[i+1:pivot_i+1])
    return i

L = [1, 4, 7, 3]
quicksort(L)
assert L == [1, 3, 4, 7]

L = [23, 3, 45, 7, 6, 11, 14, 12]
quicksort(L)
assert L == [3, 6, 7, 11, 12, 14, 23, 45]
