# -*- coding: utf-8 -*-
"""
Spyder Editor

This is a temporary script file.
"""
class Path:
    def __init__(self, path=[]):
        self.path = path

    def add(self, node):
        return Path(self.path + [node])

    def visited(self, node):
        return node in self.path

    def len(self):
        return len(self.path)

    def as_list(self):
        return self.path
    
def find_path(graph, start, end, path):
    path = path.add(start)
    if start == end:
        return path
    if start not in graph:
        return None
    for node in graph[start]:
        if not path.visited(node):
            newpath = find_path(graph, node, end, path)
            if newpath: return newpath
    return None

def find_path_main(graph, start, end):
    p = find_path(graph, start, end, Path())
    if p:
        return p.as_list()
    else:
        return p
    
def find_all_paths(graph, start, end, path):
    path = path.add(start)
    if start == end:
        return [path]
    if start not in graph:
        return []
    paths = []
    for node in graph[start]:
        if not path.visited(node):
            newpaths = find_all_paths(graph, node, end, path)
            for newpath in newpaths:
                paths.append(newpath)
    return paths

def find_all_paths_main(graph, start, end):
    return [p.as_list()
            for p in find_all_paths(graph, start, end, Path())]

def find_shortest_path(graph, start, end, path):
    path = path.add(start)
    if start == end:
        return path
    if start not in graph:
        return None
    shortest = None
    for node in graph[start]:
        if not path.visited(node):
            newpath = find_shortest_path(graph, node, end, path)
            if newpath:
                if not shortest or newpath.len() < shortest.len():
                    shortest = newpath
    return shortest

def find_shortest_path_main(graph, start, end):
    p = find_shortest_path(graph, start, end, Path())
    if p:
        return p.as_list()
    else:
        return p

# To see how inefficient this pathfinding is, let's use this trivial straight-line graph.
def straight_line(n):
    return {i: [i+1] for i in range(n)}

# Python's limit on recursion means we'll need to run several searches to get the times high enough to compare.
def perf_test(n, path):
    x = [find_path(straight_line(n), 0, n, path)
         for i in range(1000)]
    
#perf_test(1000, Path())
#print ('finished')

class EmptyLinkedPath:
    def add(self, node):
        return NonemptyLinkedPath(node, self)

    def visited(self, node):        
        return False

    def len(self):
        return 0

    def as_list(self):
        return []

class NonemptyLinkedPath:
    def __init__(self, head, tail):
        self.head = head
        self.tail = tail
    
    def add(self, node):
        return NonemptyLinkedPath(node, self)
    
    def visited(self, node):
        return node == self.head or self.tail.visited(node)
    
    def len(self):
        return 1 + self.tail.len()

    def as_list(self):
        return self.tail.as_list() + [self.head]

graph = {'A': ['B', 'C'],
         'B': ['C', 'D'],
         'C': ['D'],
         'D': ['C'],
         'E': ['F'],
         'F': ['C']}
    
#find_path(graph, 'A', 'D', EmptyLinkedPath()).as_list()
#[p.as_list() for p in find_all_paths(graph, 'A', 'D', EmptyLinkedPath())]
#find_shortest_path(graph, 'A', 'D', EmptyLinkedPath()).as_list()
#perf_test(500, EmptyLinkedPath())
#print('finished')

class LessThanPath:
    def __init__(self, bound=0):
        self.bound = bound
        # ...meaning "all consecutive positive integers less than bound."

    def add(self, node):
        if self.bound == node:
            # Good, the client code followed the pattern we optimize for.
            # The next path member comes right after the last.
            return LessThanPath(node+1)
        else:
            # Doesn't fit the pattern.  Fall back to an unoptimized path.
            p = Path()
            for i in range(0, self.bound):
                p = p.add(i)
            return p.add(node)
            # Notice that here we returned an instance of a different class,
            # which is totally legit!

    def visited(self, node):
        # Nice: this check now runs in time independent of path length!
        return 0 <= node and node < self.bound

    def len(self):
        # Ditto for computing the length.
        return self.bound

    def as_list(self):
        # This method still takes time proportional to the path length.
        # You can't win 'em all!
        return list(range(self.bound))
    
perf_test(2000, LessThanPath())
print('finished')

class RangePath:
    def __init__(self, lower=0, upper=0):
        self.lower = lower
        self.upper = upper
        # ...meaning "all integers in [lower, upper)."
        # For the default values of 0 and 0, that's an empty interval!

    def add(self, node):
        if self.lower == self.upper:
            # Empty range so far.  Switch it now to a single-element range.
            return RangePath(node, node+1)
        elif node == self.upper:
            # The range is being expanded by one position higher.
            return RangePath(self.lower, node+1)
        else:
            # Doesn't fit the pattern.  Fall back to an unoptimized path.
            p = Path()
            for i in range(self.lower, self.upper):
                p = p.add(i)
            return p.add(node)

    def visited(self, node):
        return self.lower <= node and node < self.upper

    def len(self):
        return self.upper - self.lower

    def as_list(self):
        return list(range(self.lower, self.upper))
    
perf_test(1000, RangePath())
print('finished')

def straight_line_from(fr, n):
    return {i: [i+1] for i in range(fr, fr+n)}

def perf_test_from(fr, n, path):
    x = [find_path(straight_line_from(fr, n), 0, n, path)
         for i in range(1000)]
    
perf_test_from(100, 2000, RangePath())
print('finished')
